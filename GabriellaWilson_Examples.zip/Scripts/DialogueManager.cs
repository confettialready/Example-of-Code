﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; 

public class DialogueManager : MonoBehaviour {

	public Text grassUnlock;
    public Text fireUnlock;
    public Text kitchenUnlock;
    public Text waterUnlock; 

	public Text nameText;
	public Text dialogueText;

	public GameObject DialogueBox;
	public GameObject startHolder;

    [Header("SpriteDialogueImages")]
	public Image Pikachu;
	public Image Meowth;
	public Image Skitty;
	public Image Machop; 
	public Image Bulbasaur;
    public Image Charmander;
	public Image Cyndaquill;
    public Image Eevee;
    public Image Chikorita;
    public Image TreekoAngry;
    public Image TorchicCrying;
    public Image Munchlax;
    public Image Squirtle; 

    [Header("ResourceImages")]
	public Image PokeCoinImage; 
	public Image WoodImage;
    public Image StoneImage;
    public Image BerryImage; 

    [Header("ButtonTriggers")]
	public Button meowthButton;
	public Button meowthCoinButton; 
	public Button skittyButton; 
	public Button machopButton;
	public Button buildButton; 
	public Button buildMenuButton; 
	public Button GThreeResidentsButton; 
	public Button machopWoodButton;
	public Button woodHutBuilt; 
	public Button machopFireButton;
    public Button FThreeResidentsButton; 
    public Button machopStoneButton;
    public Button skittyNorm;
    public Button machopNorm;
    public Button meowthNorm;
    public Button skittyStart;
    public Button machopStart;
    public Button meowthStart;
    public Button bulbaWoodHut;
    public Button machopFireNewButton;
    public Button charStoneHut;
    public Button skittyDecoration;
    public Button machopWaterButton;
    public Button squirtStartButton; 

    private Queue<string> sentences; 

	public static DialogueManager instance;

	void Awake () {

		instance = this; 

	}

	// Use this for initialization
	void Start () {

		sentences = new Queue<string> (); 
		
	}

	public void StartDialogue (Dialogue dialogue){

		nameText.text = dialogue.name; 

		sentences.Clear (); 

		foreach (string sentence in dialogue.sentences) {

			sentences.Enqueue (sentence);

		}

		DisplayNextSentence ();

	}

	public void DisplayNextSentence (){

		if (sentences.Count == 0) {

			EndDialogue ();
			return;

		}

		GM.instance.speaker.PlayOneShot (GM.instance.next); 

		string sentence = sentences.Dequeue ();
		dialogueText.text = sentence;

	}

	void EndDialogue(){

		Debug.Log ("End of Conversation"); 

		DialogueBox.SetActive(false); 

		Pikachu.gameObject.SetActive (false); 
		Meowth.gameObject.SetActive (false); 
		Skitty.gameObject.SetActive (false);
		Machop.gameObject.SetActive (false); 
		Bulbasaur.gameObject.SetActive (false);
        Charmander.gameObject.SetActive(false);
		Cyndaquill.gameObject.SetActive(false);
        Munchlax.gameObject.SetActive(false);
        Squirtle.gameObject.SetActive(false);

    }

}
