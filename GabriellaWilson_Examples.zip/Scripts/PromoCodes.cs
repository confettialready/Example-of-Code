﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PromoCodes : MonoBehaviour {

    public string fieldString;
    public Text fieldText; 
    public GameObject promocodeField;

    // Use this for initialization
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {

        fieldString = fieldText.text; 

    }

    public void ChangeNameOpen()
    {

        promocodeField.SetActive(true);

    }

    //when the player finishes typing in the promo code
    public void FinishType()
    {

        string Calico = PlayerPrefs.GetString("goldfishCodeCalico");
        string AIT = PlayerPrefs.GetString("goldfishCodeAIT");
        string PAX = PlayerPrefs.GetString("goldfishCodePAX"); 

        switch (fieldString)
        {
            case "TapTapCaliGo":
                PlayerPrefs.SetInt("goldfishSkinCalico", 1); 
                UpgradeManager.instance.cowico.SetActive(true);
                CowicoBehaviour.instance.goldfishTrue = true;
                CowicoBehaviour.instance.touched = true;
                UpgradeManager.instance.cowicoUPMenu.SetActive(true);
                UpgradeManager.instance.settingsMenu.SetActive(false);
                UpgradeManager.instance.cowicoYes.gameObject.SetActive(true);
                UpgradeManager.instance.cowicoNo.gameObject.SetActive(false);
                UpgradeManager.instance.cowicoYesText.gameObject.SetActive(true);
                UpgradeManager.instance.cowicoNoText.gameObject.SetActive(false);
                UpgradeManager.instance.speaker.PlayOneShot(UpgradeManager.instance.newPetSFX);
                break;

            case "AITGameDay2018":
                PlayerPrefs.SetInt("goldfishSkinAIT", 1);
                UpgradeManager.instance.ait.SetActive(true);
                AitBehaviour.instance.goldfishTrue = true;
                AitBehaviour.instance.touched = true;
                UpgradeManager.instance.aitUPMenu.SetActive(true);
                UpgradeManager.instance.settingsMenu.SetActive(false);
                UpgradeManager.instance.aitYes.gameObject.SetActive(true);
                UpgradeManager.instance.aitNo.gameObject.SetActive(false);
                UpgradeManager.instance.aitYesText.gameObject.SetActive(true);
                UpgradeManager.instance.aitNoText.gameObject.SetActive(false);
                UpgradeManager.instance.speaker.PlayOneShot(UpgradeManager.instance.newPetSFX);
                break;

            case "PAXAUS2018":
                PlayerPrefs.SetInt("goldfishSkinPAX", 1);
                UpgradeManager.instance.pax.SetActive(true);
                PAXBehaviour.instance.goldfishTrue = true;
                PAXBehaviour.instance.touched = true;
                UpgradeManager.instance.paxUPMenu.SetActive(true);
                UpgradeManager.instance.settingsMenu.SetActive(false);
                UpgradeManager.instance.paxYes.gameObject.SetActive(true);
                UpgradeManager.instance.paxNo.gameObject.SetActive(false);
                UpgradeManager.instance.paxYesText.gameObject.SetActive(true);
                UpgradeManager.instance.paxNoText.gameObject.SetActive(false);
                UpgradeManager.instance.speaker.PlayOneShot(UpgradeManager.instance.newPetSFX);
                break;

                //dev codes
            case "TTFGDevOn36249":
                Resources.shellAdjust(1000);
                break;
            case "TTFDDevOff83923":
                // Resources
                PlayerPrefs.SetInt("shells", 0);

                // Pet Active
                PlayerPrefs.SetInt("bigMommaActive", 0);
                PlayerPrefs.SetInt("seabiscuitActive",0);
                PlayerPrefs.SetInt("scratchyActive", 0);
                PlayerPrefs.SetInt("eugeneActive", 0);
                PlayerPrefs.SetInt("axieActive", 0);
                PlayerPrefs.SetInt("leoActive", 0);
                PlayerPrefs.SetInt("clambellActive", 0);
                PlayerPrefs.SetInt("timmyActive", 1);

                // SkinUnlock
                PlayerPrefs.SetInt("goldfishSkinCalico", 0);
                PlayerPrefs.SetInt("goldfishSkinClown", 0);
                PlayerPrefs.SetInt("piranhaSkinBioluminescent",0);
                PlayerPrefs.SetInt("sharkSkinTiger", 0);

                // Skin Activation
                PlayerPrefs.SetInt("goldfishActiveSkin", 0);
                PlayerPrefs.SetInt("piranhaActiveSkin", 0);
                PlayerPrefs.SetInt("sharkActiveSkin", 0);

                // Upgrade Levels
                PlayerPrefs.SetInt("goldfishUpgradeLevel", 0);
                PlayerPrefs.SetInt("piranhaUpgradeLevel", 0);
                PlayerPrefs.SetInt("sharkUpgradeLevel", 0);
                PlayerPrefs.SetInt("timmyUpgradeLevel", 0);
                PlayerPrefs.SetInt("scratchyUpgradeLevel", 0);
                PlayerPrefs.SetInt("seabiscuitUpgradeLevel", 0);
                PlayerPrefs.SetInt("eugeneUpgradeLevel",0);
                PlayerPrefs.SetInt("leoUpgradeLevel", 0);
                PlayerPrefs.SetInt("bigMommaUpgradeLevel",0);
                PlayerPrefs.SetInt("axieUpgradeLevel", 0);
                PlayerPrefs.SetInt("clambellUpgradeLevel", 0);
                PlayerPrefs.SetInt("damageUpgradeLevel", 0);
                PlayerPrefs.SetInt("foodCapUpgradeLevel", 0);
                PlayerPrefs.SetInt("popCapUpgradeLevel", 0);
                PlayerPrefs.SetInt("foodUpgradeLevel", 0);

                break;
            default: break;

        }

        promocodeField.SetActive(false);
    }
}
