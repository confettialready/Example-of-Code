﻿using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class LevelLoader : MonoBehaviour {

    public Slider slider;
    public GameObject fader;


    void Awake()
    {
        //load scene from player prefs
        StartCoroutine(Load(PlayerPrefs.GetInt("nextScene")));

    }


    //load the next scene
    IEnumerator Load (int sceneIndex)
    {

        yield return new WaitForSeconds(1);
        AsyncOperation operation = SceneManager.LoadSceneAsync(sceneIndex);
        operation.allowSceneActivation = true;
        while (!operation.isDone)
        {

            float progress = Mathf.Clamp01(operation.progress / 0.9f);
            slider.value = progress; 

            yield return null; 

        }

        fader.SetActive(true);
        yield return new WaitForSeconds(1.1f);
 

        operation.allowSceneActivation = true;
    }

    
}
