﻿
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PiranhaBehaviour : MonoBehaviour {

    public static PiranhaBehaviour instance;

    //Declaring Variables
    [Header("Setup Fields")]
    public bool findFood, piranhaTrue, eat, touched, hello, findBall;
    private Vector3 goTo, stop;
    public GameObject love, shell, ball;
    public GameObject food, arFood;
    public Transform lookAtTarget, foodTarget, firstMoveTarget, piranha, piranhaCam, ARfirstMoveTarget;
    public Transform looker;
    public Animator anim;
    public Transform camPos;
    public GameObject mainCam;
    public GameObject interactMenu;
    public GameObject killBall;

    [Header("Attributes")]
    public float moveSpeed;
    public float rotSpeed, findFoodSpeed;
    public float xPosMin, xPosMax;
    public float yPosMin, yPosMax;
    public float zPosMin, zPosMax;
    public float startTime;
    public float hunger;
    public float turnSpeed;

    // Use this for initialization
    void Awake()
    {
        startTime = 1;

        piranhaTrue = false;

        touched = false; 

        stop = new Vector3(0, 0, 1);

        instance = this;

        hello = false; 

        hunger = 0;

        //you will never find food here so always wonder around
        findFood = false;
        StartCoroutine(wander());

    }

    // Update is called once per frame
    void FixedUpdate()
    {

        if (findFood == true && UpgradeManager.instance.AR == false)
        {
            float distCovered = (Time.time - startTime);
            float fracJourney = distCovered / 3;
            Vector3 foodMove = Vector3.Slerp(firstMoveTarget.transform.position, food.transform.position, fracJourney);
            looker.LookAt(foodMove);
            nextMove(foodMove);
            piranha.rotation = Quaternion.Lerp(piranha.rotation, looker.rotation, 0.05f);
        }

        if (findFood == true && UpgradeManager.instance.AR == true)
        {
            float distCovered = (Time.time - startTime);
            float fracJourney = distCovered / 3;
            Vector3 foodMove = Vector3.Slerp(firstMoveTarget.transform.position, arFood.transform.position, fracJourney);
            looker.LookAt(foodMove);
            nextMove(foodMove);
            piranha.rotation = Quaternion.Lerp(piranha.rotation, looker.rotation, 0.05f);
        }

        //if your menu is selected
        if (piranhaTrue == true)
        {
            float distCovered = (Time.time - startTime);
            float fracJourney = distCovered / 1;
            looker.LookAt(piranhaCam);
            Vector3 menuSpot = Vector3.Lerp(piranha.transform.position, lookAtTarget.transform.position, fracJourney);
            nextMove(menuSpot);
            piranha.rotation = Quaternion.Lerp(piranha.rotation, looker.rotation, 0.05f);
        }

        //if you are clicked on and AR is off
        if (hello == true && UpgradeManager.instance.AR == false)
        {
            float distCovered = (Time.time - startTime);
            float fracJourney = distCovered / 1;
            looker.LookAt(mainCam.transform);
            Vector3 helloSpot = Vector3.Lerp(piranha.transform.position, firstMoveTarget.transform.position, fracJourney);
            nextMove(helloSpot);
            piranha.rotation = Quaternion.Lerp(piranha.rotation, looker.rotation, 0.05f);
            killBall.SetActive(true);
        }

        //if you are clicked on and AR is on
        if (hello == true && UpgradeManager.instance.AR == true)
        {
            float distCovered = (Time.time - startTime);
            float fracJourney = distCovered / 1;
            looker.LookAt(mainCam.transform);
            Vector3 helloSpot = Vector3.Lerp(piranha.transform.position, ARfirstMoveTarget.transform.position, fracJourney);
            nextMove(helloSpot);
            piranha.rotation = Quaternion.Lerp(piranha.rotation, looker.rotation, 0.05f);
            killBall.SetActive(true);
        }

        //if the ball has been thrown
        if (findBall == true)
        {
            float distCovered = (Time.time - startTime);
            float fracJourney = distCovered / 1;
            looker.LookAt(ball.transform);
            Vector3 ballPos = Vector3.Lerp(piranha.transform.position, ball.transform.position, fracJourney);
            nextMove(ballPos);
            piranha.rotation = Quaternion.Lerp(piranha.rotation, looker.rotation, 0.05f);
            killBall.SetActive(false);

        }

        //otherwise swim
        else if (piranhaTrue == false && findFood == false && hello == false && findBall == false)
        {
            moveSpeed = 12;
            nextMove(goTo);
            looker.LookAt(goTo);
            piranha.rotation = Quaternion.Lerp(piranha.rotation, looker.rotation, 0.05f);

        }

        
        //camera follow piranha
        if (touched == true)
        {
            mainCam.transform.position = Vector3.zero;
            mainCam.transform.LookAt(piranha);

        }

    }

    //when you are clicked on show heart fx and open interact menu
    void OnMouseDown()
    {

        if (UpgradeManager.instance.doNotTouch == false)
        {

            hello = true;
            love.gameObject.SetActive(true);
            interactMenu.SetActive(true);
            UpgradeManager.instance.doNotTouch = true;

        }
    }

    //turn the model in the menu
    void OnMouseDrag()
    {

        if (piranhaTrue == true && touched == true)
        {
            float rotX = Input.GetAxis("Mouse X") * turnSpeed * Mathf.Deg2Rad;
            transform.RotateAround(Vector3.up, -rotX);

        }

    }

    //function to move to your dedicated target
    void nextMove(Vector3 moveTarget)
    {
        Vector3 vel = Vector3.zero;
        transform.position = Vector3.SmoothDamp(transform.position, moveTarget, ref vel, moveSpeed * Time.deltaTime);
    }

    //Coroutine to manage changing wander position
    IEnumerator wander()
    {
        while (true)
        {
            if (!findFood) // Checks food has not been found
            {
                print("test"); // Debugging
                // Assigns a new position for the goTo variable to point to
                goTo = new Vector3(Random.Range(xPosMin, xPosMax), Random.Range(yPosMin, yPosMax), Random.Range(zPosMin, zPosMax));
                yield return new WaitForSeconds(Random.Range(2, 5)); // Waits for the assigned duration

            }
            yield return null; // Safely ends a coroutine
        }
    }

    //after you are fed poop a shell
    IEnumerator poopShell()
    {
        yield return new WaitForSeconds(5);

        UpgradeManager.instance.speaker.PlayOneShot(UpgradeManager.instance.poopShellSFX);
        shell.transform.position = piranha.transform.position;
        shell.SetActive(true);

        yield return null;


    }

}
